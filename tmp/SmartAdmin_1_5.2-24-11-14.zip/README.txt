
                        SMARTADMIN GETTING STARTED

---------------------------------------------------------------------------
                                                                          |
  Q: Looking for the unminified sources?                                  |
                                                                          |
  They are found under DEVELOPER/COMMON_ASSETS                            |
                                                                          |
---------------------------------------------------------------------------
                                                                          |
  Q: Where is the landing page sources located?                           |
                                                                          |
  They are found under DEVELOPER\COMMON_ASSETS\GOODIES\smartadmin_landing |
                                                                          |
---------------------------------------------------------------------------
                                                                          |
  Q: Do I get support with this theme?                                    |
                                                                          |
  Absolutely, but our support is limited - to view the requirements       |
  please go to www.smartadminsupport.com                                  |
                                                                          |
---------------------------------------------------------------------------
                                                                          |
  Q: Where is the full documentation?                                     |
                                                                          |  
  The full documentation can be found under the "Documentation" folder    |
---------------------------------------------------------------------------
                                                                          |
  Q: Where can I find more skins and goodies for SmartAdmin?              |
                                                                          |
  You can go to www.smartadminstore.com to find goodies and addons        |
                                                                          |
---------------------------------------------------------------------------